#ifndef HASH_H
#define HASH_H

#include <stdint.h>

uint32_t dalias_hash(char *s0);

//RcB: DEP "hash.c"

#endif
